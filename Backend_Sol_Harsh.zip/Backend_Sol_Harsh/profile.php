<html>
<form action = "submit2.php" method = "post">
                  <label>address :</label><input type = "text" name = "address" class = "box"/><br /><br />
                  <label>phone  :</label><input type = "text" name = "phone" class = "box" /><br/><br />
                  <label>college  :</label><input type = "text" name = "college" class = "box" /><br/><br />
                  <input type = "submit" value = " Submit "/> <br /><hr /> <a href="page.php">back</a><br />
               </form>
</html>