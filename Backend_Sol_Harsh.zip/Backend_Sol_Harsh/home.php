
<html">
   <?php
   session_start();
   ?>
   <head>
      <title>Welcome Guest</title>
   </head>
   
   <body>
      <h1>Welcome Guest</h1> 
      <h2><a href = "login.html">Signin</a></h2>
   </body>
   
</html>